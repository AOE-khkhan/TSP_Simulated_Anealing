package com.company;

import java.util.LinkedList;

public class NodesOfGraph {
    private  boolean isGoal=false;
    private  boolean inOpenList=false ;
    private  boolean inCloseList=false ;
    private  int seqNumOfNode ;
    private  String nodeTitle ;
    public LinkedList<EdgesOfGraph> edgesOfNode ;
    public NodesOfGraph(int seqNumOfNode,String nodeTitle){
       this.seqNumOfNode=seqNumOfNode;
       this.nodeTitle=nodeTitle ;
    }

    public void setGoal(boolean goal) {
        isGoal = goal;
    }

    public boolean isGoal() {
        return isGoal;
    }

    public boolean isInCloseList() {
        return inCloseList;
    }

    public boolean isInOpenList() {
        return inOpenList;
    }

    public void setInCloseList(boolean inCloseList) {
        this.inCloseList = inCloseList;
    }

    public void setInOpenList(boolean inOpenList) {
        this.inOpenList = inOpenList;
    }

    public int getSeqNumOfNode() {
        return seqNumOfNode;
    }

    public String getNodeTitle() {
        return nodeTitle;
    }

    //public void setEdgesOfNode(EdgesOfGraph edgesOfNode) {
       /// this.edgesOfNode = edgesOfNode;
   // }

    public void setNodeTitle(String nodeTitle) {
        this.nodeTitle = nodeTitle;
    }

    public void setSeqNumOfNode(int seqNumOfNode) {
        this.seqNumOfNode = seqNumOfNode;
    }
}
