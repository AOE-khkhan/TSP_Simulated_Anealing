package com.company;

import java.util.Random;

public class SimulatedAnnealing {
    private Graph problemState;
    private String[] nodeColors;
    private int evaluation;
    private int numOfexpand=0;
    private  int numOfVisited=0  ;

    public SimulatedAnnealing(Graph nodesOfGraph,String[] nodeColors,int evaluation) {
        this.problemState = nodesOfGraph;
        this.nodeColors = nodeColors ;
        this.evaluation=evaluation ;
    }

    public void simAnnealing() {
        int iterate = 1;
        int action = 0;
        int newE = 0;
        while ((evaluation != 0 && (iterate < 2000))) {
            Random random = new Random();
            action = (Math.abs(random.nextInt()) % 3) + 1;
            int randomNode = (Math.abs(random.nextInt())% problemState.getNumOfNode()) + 1;
            switch (action) {
                case 1:
                    newE = evaluationFunction(randomNode, NodeColor.BLUE);
                    if (!nodeColors[randomNode].equals(NodeColor.BLUE))
                        numOfVisited++ ;
                    if (evaluation > newE) {
                        if (!nodeColors[randomNode].equals(NodeColor.BLUE))
                            numOfexpand++ ;
                        evaluation = newE;
                        nodeColors[randomNode] = NodeColor.BLUE;

                    } else {
                        float p = probability(iterate);
                        int p1 =Math.abs( new Random().nextInt(100));
                        if (p == 1) {
                            if (!nodeColors[randomNode].equals(NodeColor.BLUE))
                                numOfexpand++ ;
                            evaluation = newE;
                            nodeColors[randomNode] = NodeColor.BLUE;

                        } else if (p1 <= (100 * p)) {
                            if (!nodeColors[randomNode].equals(NodeColor.BLUE))
                                numOfexpand++ ;
                            evaluation = newE;
                            nodeColors[randomNode] = NodeColor.BLUE;

                        }
                    }

                    break;
                case 2:

                    newE = evaluationFunction(randomNode, NodeColor.GREEN);
                    if (!nodeColors[randomNode].equals(NodeColor.GREEN))
                        numOfVisited++ ;
                    if (evaluation > newE) {
                        if (!nodeColors[randomNode].equals(NodeColor.GREEN))
                            numOfexpand++ ;
                        evaluation = newE;
                        nodeColors[randomNode] = NodeColor.GREEN;

                    } else {
                        float p = probability(iterate);
                        int p1 = Math.abs( new Random().nextInt(100));
                        if (p == 1) {
                            if (!nodeColors[randomNode].equals(NodeColor.GREEN))
                                numOfexpand++ ;
                            evaluation = newE;
                            nodeColors[randomNode] = NodeColor.GREEN;

                        } else if (p1 <= (100 * p)) {
                            if (!nodeColors[randomNode].equals(NodeColor.GREEN))
                                numOfexpand++ ;
                            evaluation = newE;
                            nodeColors[randomNode] = NodeColor.GREEN;

                        }
                    }
                    break;
                case 3:
                    newE = evaluationFunction(randomNode, NodeColor.RED);
                    if (!nodeColors[randomNode].equals(NodeColor.RED))
                        numOfVisited++ ;
                    if (evaluation > newE) {
                        if (!nodeColors[randomNode].equals(NodeColor.RED))
                            numOfexpand++ ;
                        evaluation = newE;
                        nodeColors[randomNode] = NodeColor.RED;

                    } else {
                        if (!nodeColors[randomNode].equals(NodeColor.RED))
                            numOfexpand++ ;
                        float p = probability(iterate);
                        int p1 = Math.abs( new Random().nextInt(100));
                        if (p == 1) {
                            evaluation = newE;
                            nodeColors[randomNode] = NodeColor.RED;

                        } else if (p1 < (100 * p)) {
                            if (!nodeColors[randomNode].equals(NodeColor.RED))
                                numOfexpand++ ;
                            evaluation = newE;
                            nodeColors[randomNode] = NodeColor.RED;

                        }
                    }

                    break;
            }
            iterate++;
        }

    }

    public int evaluationFunction(int index, String color) {
        int conflict = 0;
        for (int i = 1; i < nodeColors.length; i++) {
            NodesOfGraph currentNode = problemState.nodesOfgraph.get(i);

            for (EdgesOfGraph e : currentNode.edgesOfNode) {
                if (i == index) {
                    if (color.equals(nodeColors[e.getTail()]))
                        conflict++;
                } else {
                    if (e.getTail() == index) {
                        if (nodeColors[i].equals(color))
                            conflict++;
                    } else {
                        if (nodeColors[i].equals(nodeColors[e.getTail()]))
                            conflict++;
                    }
                }
            }
        }
        return conflict / 2;
    }

    public float probability(int i) {
        float p = 0;
        p = (1 / i);
        return p;
    }

    public void showColor() {
        System.out.println("EvaluationFunction :" + evaluation);
        System.out.println("number Of node that visited :" + numOfVisited);
        System.out.println("number Of node that expanded :" + numOfexpand);
        int i=0 ;
        for (String s : nodeColors) {
            if(i!=0)
                System.out.println(i+" : "+s);
            i++;
        }
    }
}
