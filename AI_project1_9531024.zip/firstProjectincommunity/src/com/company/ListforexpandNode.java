package com.company;

public class ListforexpandNode {
    private NodesOfGraph childNode ;
    private NodesOfGraph parentNode ;
    public ListforexpandNode(NodesOfGraph parentNode,NodesOfGraph childNode){
       this.childNode=childNode;
       this.parentNode=parentNode ;
    }

    public NodesOfGraph getChildNode() {
        return childNode;
    }

    public NodesOfGraph getParentNode() {
        return parentNode;
    }
}
