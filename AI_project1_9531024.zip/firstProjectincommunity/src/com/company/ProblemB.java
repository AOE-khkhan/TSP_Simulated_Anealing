package com.company;

import java.util.ArrayList;

public class ProblemB {
    private Graph colorGraph;
    private String[] nodeColors;
    private ArrayList<NodesOfGraph> listState;
    private float[] heuristic;

    public ProblemB() {
        colorGraph = new Graph(11);
        nodeColors = new String[12];

    }


    public ArrayList<EdgesOfGraph> creatEdges() {
        ArrayList<EdgesOfGraph> e = new ArrayList<>();
        e.add(null);
        colorGraph.nodesOfgraph.get(1).edgesOfNode.add(new EdgesOfGraph(1, 2, 0));
        colorGraph.nodesOfgraph.get(1).edgesOfNode.add(new EdgesOfGraph(1, 5, 0));
        colorGraph.nodesOfgraph.get(1).edgesOfNode.add(new EdgesOfGraph(1, 7, 0));
        colorGraph.nodesOfgraph.get(1).edgesOfNode.add(new EdgesOfGraph(1, 10, 0));
        colorGraph.nodesOfgraph.get(2).edgesOfNode.add(new EdgesOfGraph(2, 1, 0));
        colorGraph.nodesOfgraph.get(2).edgesOfNode.add(new EdgesOfGraph(2, 3, 0));
        colorGraph.nodesOfgraph.get(2).edgesOfNode.add(new EdgesOfGraph(2, 10, 0));
        colorGraph.nodesOfgraph.get(2).edgesOfNode.add(new EdgesOfGraph(2, 11, 0));
        colorGraph.nodesOfgraph.get(3).edgesOfNode.add(new EdgesOfGraph(3, 2, 0));
        colorGraph.nodesOfgraph.get(3).edgesOfNode.add(new EdgesOfGraph(3, 4, 0));
        colorGraph.nodesOfgraph.get(4).edgesOfNode.add(new EdgesOfGraph(4, 5, 0));
        colorGraph.nodesOfgraph.get(4).edgesOfNode.add(new EdgesOfGraph(4, 3, 0));
        colorGraph.nodesOfgraph.get(4).edgesOfNode.add(new EdgesOfGraph(4, 11, 0));
        colorGraph.nodesOfgraph.get(5).edgesOfNode.add(new EdgesOfGraph(5, 4, 0));
        colorGraph.nodesOfgraph.get(5).edgesOfNode.add(new EdgesOfGraph(5, 6, 0));
        colorGraph.nodesOfgraph.get(5).edgesOfNode.add(new EdgesOfGraph(5, 10, 0));
        colorGraph.nodesOfgraph.get(5).edgesOfNode.add(new EdgesOfGraph(6, 5, 0));
        colorGraph.nodesOfgraph.get(6).edgesOfNode.add(new EdgesOfGraph(6, 7, 0));
        colorGraph.nodesOfgraph.get(6).edgesOfNode.add(new EdgesOfGraph(6, 11, 0));
        colorGraph.nodesOfgraph.get(7).edgesOfNode.add(new EdgesOfGraph(7, 2, 0));
        colorGraph.nodesOfgraph.get(7).edgesOfNode.add(new EdgesOfGraph(7, 6, 0));
        colorGraph.nodesOfgraph.get(7).edgesOfNode.add(new EdgesOfGraph(7, 8, 0));
        colorGraph.nodesOfgraph.get(7).edgesOfNode.add(new EdgesOfGraph(7, 10, 0));
        colorGraph.nodesOfgraph.get(8).edgesOfNode.add(new EdgesOfGraph(8, 7, 0));
        colorGraph.nodesOfgraph.get(8).edgesOfNode.add(new EdgesOfGraph(8, 9, 0));
        colorGraph.nodesOfgraph.get(8).edgesOfNode.add(new EdgesOfGraph(8, 11, 0));
        colorGraph.nodesOfgraph.get(9).edgesOfNode.add(new EdgesOfGraph(9, 8, 0));
        colorGraph.nodesOfgraph.get(9).edgesOfNode.add(new EdgesOfGraph(9, 10, 0));
        colorGraph.nodesOfgraph.get(10).edgesOfNode.add(new EdgesOfGraph(10, 1, 0));
        colorGraph.nodesOfgraph.get(10).edgesOfNode.add(new EdgesOfGraph(10, 2, 0));
        colorGraph.nodesOfgraph.get(10).edgesOfNode.add(new EdgesOfGraph(10, 5, 0));
        colorGraph.nodesOfgraph.get(10).edgesOfNode.add(new EdgesOfGraph(10, 9, 0));
        colorGraph.nodesOfgraph.get(10).edgesOfNode.add(new EdgesOfGraph(10, 11, 0));
        colorGraph.nodesOfgraph.get(11).edgesOfNode.add(new EdgesOfGraph(11, 2, 0));
        colorGraph.nodesOfgraph.get(11).edgesOfNode.add(new EdgesOfGraph(11, 4, 0));
        colorGraph.nodesOfgraph.get(11).edgesOfNode.add(new EdgesOfGraph(11, 6, 0));
        colorGraph.nodesOfgraph.get(11).edgesOfNode.add(new EdgesOfGraph(11, 8, 0));
        colorGraph.nodesOfgraph.get(11).edgesOfNode.add(new EdgesOfGraph(11, 10, 0));
        return e;
    }

    public void creatNode() {
        // cityGraph.nodesOfgraph.add(null);

        NodesOfGraph node1 = new NodesOfGraph(1, "1");
        colorGraph.addNodetoGraph(node1);
        NodesOfGraph node2 = new NodesOfGraph(2, "2");
        colorGraph.addNodetoGraph(node2);
        NodesOfGraph node3 = new NodesOfGraph(3, "3");
        colorGraph.addNodetoGraph(node3);
        NodesOfGraph node4 = new NodesOfGraph(4, "4");
        colorGraph.addNodetoGraph(node4);
        NodesOfGraph node5 = new NodesOfGraph(5, "5");
        colorGraph.addNodetoGraph(node5);
        NodesOfGraph node6 = new NodesOfGraph(6, "6");
        colorGraph.addNodetoGraph(node6);
        NodesOfGraph node7 = new NodesOfGraph(7, "7");
        colorGraph.addNodetoGraph(node7);
        NodesOfGraph node8 = new NodesOfGraph(8, "8");
        colorGraph.addNodetoGraph(node8);
        NodesOfGraph node9 = new NodesOfGraph(9, "9");
        colorGraph.addNodetoGraph(node9);
        NodesOfGraph node10 = new NodesOfGraph(10, "10");
        colorGraph.addNodetoGraph(node10);
        NodesOfGraph node11 = new NodesOfGraph(11, "11");
        colorGraph.addNodetoGraph(node11);

    }

    public void createColorGraph() {
        creatNode();
        creatEdges();
        setInitialState();
        HillClimming hillClimming=new HillClimming(colorGraph,nodeColors,evaluationFunction());
//        hillClimming.hillSearchGreedy();
//        hillClimming.hillSearchSh();
//        hillClimming.hillSearchFirst();
//        hillClimming.ranomStart();
//        hillClimming.showColor();
//        SimulatedAnnealing simulatedAnnealing=new SimulatedAnnealing(colorGraph,nodeColors,evaluationFunction());
//        simulatedAnnealing.simAnnealing();
//        simulatedAnnealing.showColor();
//        Genetic genetic=new Genetic(colorGraph,1000,20,5,(float) 0.1);
//        genetic.runGenetic();
//        genetic.showColor();
    }

    public void printGraph() {
        for (int i = 1; i < colorGraph.nodesOfgraph.size(); i++) {
            System.out.println("---------------------------------");
            System.out.println(colorGraph.nodesOfgraph.get(i).getNodeTitle() + "***");
            System.out.println();
            for (EdgesOfGraph e : colorGraph.nodesOfgraph.get(i).edgesOfNode)
                System.out.println(e.getTail() + "-->" + e.getHead() + "cost:" + e.getCostOfEdge());
            System.out.println("********************************");

        }
    }


    public void setInitialState() {
        for (int i = 0; i < 12; i++) {
            nodeColors[i] = NodeColor.BLUE;
        }
    }

    public int evaluationFunction() {
        int conflict = 0;
        for (int i = 1; i < nodeColors.length; i++) {
            NodesOfGraph currentNode = colorGraph.nodesOfgraph.get(i);
            for (EdgesOfGraph e : currentNode.edgesOfNode) {
                if (nodeColors[i].equals(nodeColors[e.getTail()]))
                    conflict++;
            }
        }
        return conflict / 2;
    }


}


