package com.company;

import java.util.ArrayList;

public class ASSearch {
    private Graph problemStates;
    private float totalCost = 0;
    private  float[] heuristic;//=new float[problemStates.getNumOfNode()+1];
    private ArrayList<PathCostList> openlist;
    private ArrayList<PathCostList> closeList;
    private ArrayList<NodesOfGraph> foundedPath;
    private NodesOfGraph[] parents;
    private int numOfnodeVisit = 1;
    private int numOfnodexpand = 0;
    private float   costPath ;
    public ASSearch(Graph problemStates,float[] heuristic) {

        this.problemStates = problemStates;
        foundedPath = new ArrayList();
        openlist = new ArrayList<>();
        closeList = new ArrayList();
       this. heuristic=heuristic;
        parents = new NodesOfGraph[problemStates.getNumOfNode()+1];

    }

    public boolean ASSearchGraph() {
        NodesOfGraph startState = problemStates.nodesOfgraph.get(1);
        PathCostList currentState = null;
        if (startState.isGoal()) foundedPath.add(startState);
        openlist.add(new PathCostList(startState, 0));
        parents[startState.getSeqNumOfNode()]= null;
        startState.setInOpenList(true);
        while (!PathCostList.isEmpty(openlist)) {
            currentState = PathCostList.getShortestPathAs(openlist,heuristic);
            closeList.add(currentState);
            currentState.nodesOfGraph.setInCloseList(true);
            numOfnodexpand++;
            if (currentState.nodesOfGraph.isGoal()) {
                solution(parents, currentState.nodesOfGraph, currentState.nodesOfGraph);
                totalCost = PathCostList.findNode(closeList, currentState.nodesOfGraph).totalCost;
                System.out.println(totalCost + "tatal cost");
                return false;
            }
            for (EdgesOfGraph e :
                    currentState.nodesOfGraph.edgesOfNode) {
                if (!problemStates.nodesOfgraph.get(e.getTail()).isInOpenList() && !problemStates.nodesOfgraph.get(e.getTail()).isInCloseList()) {

                  //  openlist.add(new PathCostList(problemStates.nodesOfgraph.get(e.getTail()),heuristic[e.getTail()] ));
                    openlist.add(new PathCostList(problemStates.nodesOfgraph.get(e.getTail()), currentState.totalCost + e.getCostOfEdge()));
                    parents[e.getTail()] =currentState.nodesOfGraph;
                    problemStates.nodesOfgraph.get(e.getTail()).setInOpenList(true);
                    numOfnodeVisit++;
                } else if (problemStates.nodesOfgraph.get(e.getTail()).isInCloseList()) {
                    if ((currentState.totalCost + e.getCostOfEdge()) < PathCostList.findNode(closeList, problemStates.nodesOfgraph.get(e.getTail())).totalCost) {
                        closeList.remove(PathCostList.findNode(closeList, problemStates.nodesOfgraph.get(e.getTail())));
                        openlist.add(new PathCostList( problemStates.nodesOfgraph.get(e.getTail()), currentState.totalCost + e.getCostOfEdge()));
                        problemStates.nodesOfgraph.get(e.getTail()).setInCloseList(false) ;
                        parents[e.getTail()]= currentState.nodesOfGraph;
                    }

                } else if (problemStates.nodesOfgraph.get(e.getTail()).isInOpenList()) {
                    if ((currentState.totalCost + e.getCostOfEdge()) < PathCostList.findNode(openlist, problemStates.nodesOfgraph.get(e.getTail())).totalCost) {
                        // openlist.add(new PathCostList(PathCostList.findNode(openlist, problemStates.nodesOfgraph.get(e.getTail())).nodesOfGraph, currentState.totalCost + e.getCostOfEdge()));
                        //openlist.remove(PathCostList.findNode(openlist, problemStates.nodesOfgraph.get(e.getTail())));

                        PathCostList.findNode(openlist, problemStates.nodesOfgraph.get(e.getTail())).totalCost= currentState.totalCost + e.getCostOfEdge();

                    }
                }
            }

        }
        return false;

    }
    public boolean ASSearchTree() {
        NodesOfGraph startState = problemStates.nodesOfgraph.get(1);
        PathCostList currentState = null;
        if (startState.isGoal()) foundedPath.add(startState);
        openlist.add(new PathCostList(startState, 0));
        parents[startState.getSeqNumOfNode()]= null;
        startState.setInOpenList(true);
        startState.setInCloseList(true);
        while (!PathCostList.isEmpty(openlist)) {
            currentState = PathCostList.getShortestPathAs(openlist,heuristic);
            currentState.nodesOfGraph.setInOpenList(false);
            numOfnodexpand++;
            if (currentState.nodesOfGraph.isGoal()) {
                solution(parents, currentState.nodesOfGraph, currentState.nodesOfGraph);

                totalCost = currentState.totalCost;
                System.out.println(totalCost + "tatal cost");
                return true;
            }
            for (EdgesOfGraph e :
                    currentState.nodesOfGraph.edgesOfNode) {
                if (!problemStates.nodesOfgraph.get(e.getTail()).isInOpenList() && !problemStates.nodesOfgraph.get(e.getTail()).isInCloseList()) {

                    //  openlist.add(new PathCostList(problemStates.nodesOfgraph.get(e.getTail()),heuristic[e.getTail()] ));
                    openlist.add(new PathCostList(problemStates.nodesOfgraph.get(e.getTail()), currentState.totalCost + e.getCostOfEdge()));
                    if (!problemStates.nodesOfgraph.get(e.getTail()).isInCloseList()) {
                        parents[e.getTail()] = currentState.nodesOfGraph;
                        problemStates.nodesOfgraph.get(e.getTail()).setInCloseList(true);
                    }
                    problemStates.nodesOfgraph.get(e.getTail()).setInOpenList(true);
                    numOfnodeVisit++;
                }  else if (problemStates.nodesOfgraph.get(e.getTail()).isInOpenList()) {
                    if ((currentState.totalCost + e.getCostOfEdge()) < PathCostList.findNode(openlist, problemStates.nodesOfgraph.get(e.getTail())).totalCost) {
                        // openlist.add(new PathCostList(PathCostList.findNode(openlist, problemStates.nodesOfgraph.get(e.getTail())).nodesOfGraph, currentState.totalCost + e.getCostOfEdge()));
                        //openlist.remove(PathCostList.findNode(openlist, problemStates.nodesOfgraph.get(e.getTail())));

                        PathCostList.findNode(openlist, problemStates.nodesOfgraph.get(e.getTail())).totalCost= currentState.totalCost + e.getCostOfEdge();
                        parents[e.getTail()]=currentState.nodesOfGraph ;


                    }
                }
            }

        }
        return false;

    }

    public ArrayList<NodesOfGraph> solution(NodesOfGraph[] closeList, NodesOfGraph parentGoal, NodesOfGraph goal) {
        foundedPath.add(goal);
        foundedPath.add(closeList[goal.getSeqNumOfNode()]);
        NodesOfGraph parentNode = closeList[goal.getSeqNumOfNode()];
        while (closeList[parentNode.getSeqNumOfNode()] != null) {
            if (closeList[parentNode.getSeqNumOfNode()] != null) {
                foundedPath.add(closeList[parentNode.getSeqNumOfNode()]);
                parentNode = closeList[parentNode.getSeqNumOfNode()];

            }


        }
        return foundedPath;
    }

    public void showPath() {
        for (NodesOfGraph node :
                foundedPath) {
            System.out.printf(node.getNodeTitle() + "<--");
        }
        System.out.println();
        System.out.println("Cost:"+totalCost);
        System.out.println("Expand:"+numOfnodexpand);
        System.out.println("visit:"+numOfnodeVisit);
    }
}
