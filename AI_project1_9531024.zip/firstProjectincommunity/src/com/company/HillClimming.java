package com.company;

import java.util.Random;

public class HillClimming {
    private Graph problemState;
    private String[] nodeColors;
    private int evaluation;
    private int numOfvisited = 0;
    private int numOfexpand = 0;

    public HillClimming(Graph nodesOfGraph, String[] nodeColors, int evaluation) {
        this.problemState = nodesOfGraph;
        this.nodeColors = nodeColors;
        this.evaluation = evaluation;
    }

    public void hillSearchGreedy() {
        int iterate = 0;
        int action = 0;
        int pastEvalu=evaluation;
        while ((evaluation != 0 && (iterate < 2000))) {

            for (int i = 1; i < problemState.nodesOfgraph.size(); i++) {
                action = 0;
                int newE = evaluationFunction(i, NodeColor.BLUE);
                if (!nodeColors[i].equals(NodeColor.BLUE))
                    numOfvisited++;
                if (evaluation > newE) {
                    evaluation = newE;
                    action = 1;
                }
                newE = evaluationFunction(i, NodeColor.GREEN);
                if (!nodeColors[i].equals(NodeColor.GREEN))
                    numOfvisited++;
                numOfvisited++;
                if (evaluation > newE) {
                    evaluation = newE;
                    action = 2;
                }
                newE = evaluationFunction(i, NodeColor.RED);
                if (!nodeColors[i].equals(NodeColor.RED))
                    numOfvisited++;
                if (evaluation > newE) {
                    evaluation = newE;
                    action = 3;
                }
                switch (action) {
                    case 1:
                        if (!nodeColors[i].equals(NodeColor.BLUE))
                            numOfexpand++;
                        nodeColors[i] = NodeColor.BLUE;
                        break;
                    case 2:
                        if (!nodeColors[i].equals(NodeColor.GREEN))
                            numOfexpand++;
                        nodeColors[i] = NodeColor.GREEN;
                        break;
                    case 3:
                        if (!nodeColors[i].equals(NodeColor.RED))
                            numOfexpand++;
                        nodeColors[i] = NodeColor.RED;
                        break;
                }
            }
            if (evaluation==pastEvalu)
                break;
            pastEvalu=evaluation;
            iterate++;
            if (evaluation == 0)
                break;
        }
        System.out.println(evaluation + "e");

    }

    public void hillSearchSh() {
        int iterate = 0;
        int action = 0;
        int pastEvalu=evaluation;
        String[] betterState = new String[3];
        while ((evaluation != 0 && (iterate < 2000))) {

            for (int i = 1; i < problemState.nodesOfgraph.size(); i++) {
                Random random = new Random();
                action = 0;
                int newE;
                newE = evaluationFunction(i, NodeColor.BLUE);
                if (evaluation > newE) {
                    betterState[action] = NodeColor.BLUE;
                    action++;
                }
                if (!nodeColors[i].equals(NodeColor.GREEN))
                    numOfvisited++;
                newE = evaluationFunction(i, NodeColor.GREEN);
                if (evaluation > newE) {
                    betterState[action] = NodeColor.GREEN;
                    action++;
                }
                if (!nodeColors[i].equals(NodeColor.RED))
                    numOfvisited++;
                newE = evaluationFunction(i, NodeColor.RED);
                if (evaluation > newE) {
                    betterState[action] = NodeColor.RED;
                    action++;
                }
                if (!nodeColors[i].equals(NodeColor.RED))
                    numOfvisited++;
                if (action == 0)
                    break;
                int randomA = (Math.abs(random.nextInt()) % action);
                switch (randomA) {
                    case 0:
                        if (!nodeColors[i].equals(NodeColor.BLUE))
                            numOfexpand++;
                        nodeColors[i] = betterState[0];
                        break;
                    case 1:
                        if (!nodeColors[i].equals(NodeColor.GREEN))
                            numOfexpand++;
                        nodeColors[i] = betterState[1];
                        break;
                    case 2:
                        if (!nodeColors[i].equals(NodeColor.RED))
                            numOfexpand++;
                        nodeColors[i] = betterState[2];
                        break;
                }
            }
            if (evaluation==pastEvalu)
                break;
            pastEvalu=evaluation;
            if (action == 0)
                break;
            iterate++;
        }


    }

    public void hillSearchFirst() {
        int iterate = 0, pastEvalu = evaluation;
        boolean action = false;
        while ((evaluation != 0 && (iterate < 2000))) {
            for (int i = 1; i < problemState.nodesOfgraph.size(); i++) {
                action = false;
                int newE = evaluationFunction(i, NodeColor.BLUE);
                if (!nodeColors[i].equals(NodeColor.BLUE))
                    numOfvisited++;
                if (evaluation > newE) {
                    if (!nodeColors[i].equals(NodeColor.BLUE))
                        numOfexpand++;
                    evaluation = newE;
                    nodeColors[i] = NodeColor.BLUE;
                    action = true;
                }
                newE = evaluationFunction(i, NodeColor.GREEN);
                if (!nodeColors[i].equals(NodeColor.GREEN))
                    numOfvisited++;
                if (evaluation > newE && !action) {
                    if (!nodeColors[i].equals(NodeColor.GREEN))
                        numOfexpand++;
                    evaluation = newE;
                    nodeColors[i] = NodeColor.GREEN;
                    action = true;
                }
                newE = evaluationFunction(i, NodeColor.RED);
                if (!nodeColors[i].equals(NodeColor.RED))
                    numOfvisited++;
                if (evaluation > newE && !action) {
                    if (!nodeColors[i].equals(NodeColor.RED))
                        numOfexpand++;
                    evaluation = newE;
                    nodeColors[i] = NodeColor.RED;
                    action = true;
                }

            }
            if (evaluation==pastEvalu)
                break;
            pastEvalu=evaluation;
            iterate++;
        }
    }

    public int evaluationFunction(int index, String color) {
        int conflict = 0;
        for (int i = 1; i < nodeColors.length; i++) {
            NodesOfGraph currentNode = problemState.nodesOfgraph.get(i);

            for (EdgesOfGraph e : currentNode.edgesOfNode) {
                if (i == index) {
                    if (color.equals(nodeColors[e.getTail()]))
                        conflict++;
                } else {
                    if (e.getTail() == index) {
                        if (nodeColors[i].equals(color))
                            conflict++;
                    } else {
                        if (nodeColors[i].equals(nodeColors[e.getTail()]))
                            conflict++;
                    }
                }
            }
        }
        return conflict / 2;
    }

    public void ranomStart() {
        int iteratve = 0;
        while (evaluation != 0 && iteratve < 2000) {
            hillSearchGreedy();
            for (int j = 1; j < problemState.getNumOfNode() + 1; j++) {
                Random random = new Random();
                int randomColor = (Math.abs(random.nextInt()) % 3) + 1;
                switch (randomColor) {
                    case 1:
                        nodeColors[j] = NodeColor.BLUE;
                        break;
                    case 2:
                        nodeColors[j] = NodeColor.GREEN;
                        break;
                    case 3:
                        nodeColors[j] = NodeColor.RED;
                        break;
                }
            }
        }

    }

    public void showColor() {
        System.out.println("EvaluationFunction :" + evaluation);
        System.out.println("number Of node that visited :" + numOfvisited);
        System.out.println("number Of node that expanded :" + numOfexpand);
        int i = 0;
        for (String s : nodeColors) {
            if (i != 0)
                System.out.println(i + " : " + s);
            i++;
        }
    }
}
