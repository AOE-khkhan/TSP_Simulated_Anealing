package com.company;
import org.opencv.android.* ;

import java.util.ArrayList;

public class Main {

  public static void main(String[] args) {
//        NodesOfGraph node1 =new NodesOfGraph(1,"I");
//        NodesOfGraph node2 =new NodesOfGraph(2,"A");
//        NodesOfGraph node3 =new NodesOfGraph(3,"B");
//        NodesOfGraph node4 =new NodesOfGraph(4,"C");
//        NodesOfGraph node5 =new NodesOfGraph(5,"D");
//        NodesOfGraph node6 =new NodesOfGraph(6,"E");
//        NodesOfGraph node7 =new NodesOfGraph(7,"F");
//        NodesOfGraph node8 =new NodesOfGraph(8,"H");
//        NodesOfGraph node9 =new NodesOfGraph(9,"G");
//        node9.setGoal(true);
//
//        Graph graph=new Graph(9) ;
//        graph.addNodetoGraph(node1);
//        graph.addNodetoGraph(node2);
//        graph.addNodetoGraph(node3);
//        graph.addNodetoGraph(node4);
//        graph.addNodetoGraph(node5);
//        graph.addNodetoGraph(node6);
//        graph.addNodetoGraph(node7);
//        graph.addNodetoGraph(node8);
//        graph.addNodetoGraph(node9);
//        graph.addEdgetoGraph(1,new EdgesOfGraph(1,3,80));
//        graph.addEdgetoGraph(1,new EdgesOfGraph(1,2,100));
//        graph.addEdgetoGraph(2,new EdgesOfGraph(2,1,80));
//        graph.addEdgetoGraph(2,new EdgesOfGraph(2,4,500));
//        graph.addEdgetoGraph(2,new EdgesOfGraph(2,5,400));
//        graph.addEdgetoGraph(2,new EdgesOfGraph(2,6,30));
//       graph.addEdgetoGraph(3,new EdgesOfGraph(3,1,100));
//        graph.addEdgetoGraph(3,new EdgesOfGraph(3,7,50));
//        graph.addEdgetoGraph(3,new EdgesOfGraph(3,8,70));
//        graph.addEdgetoGraph(4,new EdgesOfGraph(4,2,500));
//        graph.addEdgetoGraph(4,new EdgesOfGraph(4,5,200));
//        graph.addEdgetoGraph(5,new EdgesOfGraph(5,2,400));
//        graph.addEdgetoGraph(5,new EdgesOfGraph(5,4,200));
//        graph.addEdgetoGraph(6,new EdgesOfGraph(6,2,30));
//        graph.addEdgetoGraph(6,new EdgesOfGraph(6,7,10));
//        graph.addEdgetoGraph(7,new EdgesOfGraph(7,3,50));
//        graph.addEdgetoGraph(7,new EdgesOfGraph(7,6,10));
//        graph.addEdgetoGraph(7,new EdgesOfGraph(7,9,5));
//        graph.addEdgetoGraph(8,new EdgesOfGraph(8,3,70));
//        graph.addEdgetoGraph(8,new EdgesOfGraph(8,9,60));
//        graph.addEdgetoGraph(9,new EdgesOfGraph(9,7,5));
//        graph.addEdgetoGraph(9,new EdgesOfGraph(9,8,60));
//    ProblemA city=new ProblemA();
//    city.creatCityGraph();
        ProblemB coloring=new ProblemB();
        coloring.createColorGraph();
//       coloring.printGraph();
//        HillClimming hillClimming=new HillClimming(graph);
//        hillClimming.hillSearchFirst();
//        hillClimming.showColor();
//
//SimulatedAnnealing simulatedAnnealing=new SimulatedAnnealing(graph);
//simulatedAnnealing.simAnnealing();
//simulatedAnnealing.showColor();



    }

}
