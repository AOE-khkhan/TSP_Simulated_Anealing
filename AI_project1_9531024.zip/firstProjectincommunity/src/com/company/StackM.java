package com.company;

import java.util.ArrayList;
import java.util.Stack;

public class StackM <E> {
    private  int front ;
    private  int top ;
    private  int maxSize;
    ArrayList<E> stack;
    public StackM(int maxSize){
        this.maxSize=maxSize;
        front=0;//
        top=0;
        stack=new ArrayList<>();
    }
    public void  addToStack(E e){
        if (top==maxSize)
            return;
        else{
           stack.add(top,e);
            top++;
        }

    }
    public E  getFromStack(){

        if (top==front)
            return null ;
        else{
            int t=top;
            top--;
            return    stack.remove(top);

        }


    }

    public boolean empty() {
        if(top==front)
            return true;
        else
            return false ;
    }
}
