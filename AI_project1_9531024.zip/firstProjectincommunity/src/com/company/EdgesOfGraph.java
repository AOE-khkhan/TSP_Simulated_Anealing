package com.company;

public class EdgesOfGraph {
    private int head ;
    private int tail;
    private float costOfEdge ;
   public   boolean visit;
    public EdgesOfGraph nextEdge ;
    public EdgesOfGraph(int head,int tail,float costOfEdge  ){
        this.costOfEdge=costOfEdge;
        this.head=head;
        this.tail=tail ;
        this.visit=false ;

    }

    public int getHead() {
        return head;
    }
    public int getTail(){
        return tail;
    }
    public float getCostOfEdge(){
        return  costOfEdge;
    }
    public void setHead(int head){
        this.head=head;
    }
    public void setTail(int tail){
        this.tail=tail;
    }

    public void setCostOfEdge(float costOfEdge) {
        this.costOfEdge = costOfEdge;
    }
}
