package com.company;

import java.util.ArrayList;

public class ProblemA {
    private Graph cityGraph;
    private ArrayList<NodesOfGraph> listState;
    private float[] heuristic;

    public ProblemA() {
        cityGraph = new Graph(20);
        listState = new ArrayList<>();
    }

    public void setHeuristic() {
        heuristic = new float[21];
        heuristic[1] = 366;
        heuristic[2] = 0;
        heuristic[3] = 160;
        heuristic[4] = 242;
        heuristic[5] = 161;
        heuristic[6] = 178;
        heuristic[7] = 77;
        heuristic[8] = 151;
        heuristic[9] = 226;
        heuristic[10] = 244;
        heuristic[11] = 241;
        heuristic[12] = 234;
        heuristic[13] = 380;
        heuristic[14] = 98;
        heuristic[15] = 196;
        heuristic[16] = 253;
        heuristic[17] = 329;
        heuristic[18] = 80;
        heuristic[19] = 199;
        heuristic[20] = 374;

    }

    public ArrayList<EdgesOfGraph> creatActios() {
        ArrayList<EdgesOfGraph> e = new ArrayList<>();
        e.add(null);
        e.add(new EdgesOfGraph(1, 17, computeCostOfAction("arad", "timisoara")));
        e.add(new EdgesOfGraph(1, 16, computeCostOfAction("arad", "sibiu")));
//        e.add(new EdgesOfGraph(1, 17, computeCostOfAction("arad", "timisoara")));
        e.add(new EdgesOfGraph(1, 20, computeCostOfAction("arad", "zernid")));
        e.add(new EdgesOfGraph(2, 6, computeCostOfAction("bucharest", "fagaras")));
        e.add(new EdgesOfGraph(2, 14, computeCostOfAction("bucharest", "pitesti")));
        e.add(new EdgesOfGraph(2, 18, computeCostOfAction("bucharest", "urziceni")));
        e.add(new EdgesOfGraph(2, 7, computeCostOfAction("bucharest", "giurgiu")));
        e.add(new EdgesOfGraph(3, 14, computeCostOfAction("craiova", "pitesti")));
        e.add(new EdgesOfGraph(3, 15, computeCostOfAction("craiova", "rimnicu vilcea")));
        e.add(new EdgesOfGraph(3, 4, computeCostOfAction("craiova", "dobreta")));
        e.add(new EdgesOfGraph(4, 3, computeCostOfAction("dobreta", "craiova")));
        e.add(new EdgesOfGraph(4, 11, computeCostOfAction("dobreta", "mehadia")));
        e.add(new EdgesOfGraph(5, 8, computeCostOfAction("eforie", "hirsova")));
        e.add(new EdgesOfGraph(6, 2, computeCostOfAction("fagaras", "bucharest")));
        e.add(new EdgesOfGraph(6, 16, computeCostOfAction("fagaras", "sibiu")));
        e.add(new EdgesOfGraph(7, 2, computeCostOfAction("giurgiu", "bucharest")));
        e.add(new EdgesOfGraph(8, 18, computeCostOfAction("hirsova", "urziceni")));
        e.add(new EdgesOfGraph(8, 5, computeCostOfAction("hirsova", "eforie")));
        e.add(new EdgesOfGraph(9, 19, computeCostOfAction("lasi", "vaslui")));
        e.add(new EdgesOfGraph(9, 12, computeCostOfAction("lasi", "neamt")));
        e.add(new EdgesOfGraph(10, 17, computeCostOfAction("lugoj", "timisoara")));
        e.add(new EdgesOfGraph(10, 11, computeCostOfAction("lugoj", "mehadia")));
        e.add(new EdgesOfGraph(11, 10, computeCostOfAction("mehadia", "lugoj")));
        e.add(new EdgesOfGraph(11, 4, computeCostOfAction("mehadia", "doberta")));
        e.add(new EdgesOfGraph(12, 9, computeCostOfAction("neamt", "lasi")));
        e.add(new EdgesOfGraph(13, 16, computeCostOfAction("oradea", "sibiu")));
        e.add(new EdgesOfGraph(13, 20, computeCostOfAction("oradea", "zernid")));
        e.add(new EdgesOfGraph(14, 3, computeCostOfAction("pitesti", "craiova")));
        e.add(new EdgesOfGraph(14, 2, computeCostOfAction("pitesti", "bucharest")));
        e.add(new EdgesOfGraph(14, 15, computeCostOfAction("pitesti", "rimnicu vilcea")));
        e.add(new EdgesOfGraph(15, 3, computeCostOfAction("rimnicu vilcea", "craiova")));
        e.add(new EdgesOfGraph(15, 14, computeCostOfAction("rimnicu vilcea", "pitesti")));
        e.add(new EdgesOfGraph(15, 16, computeCostOfAction("rimnicu vilcea", "sibiu")));
        e.add(new EdgesOfGraph(16, 15, computeCostOfAction("sibiu", "rimnicu vilcea")));
        e.add(new EdgesOfGraph(16, 6, computeCostOfAction("sibiu", "fagaras")));
        e.add(new EdgesOfGraph(16, 13, computeCostOfAction("sibiu", "oradea")));
        e.add(new EdgesOfGraph(16, 1, computeCostOfAction("sibiu", "arad")));
        e.add(new EdgesOfGraph(17, 1, computeCostOfAction("timisoara", "arad")));
        e.add(new EdgesOfGraph(17, 10, computeCostOfAction("timisoara", "lugoj")));
        e.add(new EdgesOfGraph(18, 8, computeCostOfAction("urziceni", "hirsova")));
        e.add(new EdgesOfGraph(18, 19, computeCostOfAction("urziceni", "vaslui")));
        e.add(new EdgesOfGraph(18, 2, computeCostOfAction("urziceni", "bucharest")));
        e.add(new EdgesOfGraph(19, 9, computeCostOfAction("vaslui", "lasi")));
        e.add(new EdgesOfGraph(19, 18, computeCostOfAction("vaslui", "urziceni")));
        e.add(new EdgesOfGraph(20, 1, computeCostOfAction("zerind", "arad")));
        e.add(new EdgesOfGraph(20, 13, computeCostOfAction("zerind", "oradea")));

        return e;
    }

    public void creatState() {
        // cityGraph.nodesOfgraph.add(null);

        NodesOfGraph node1 = new NodesOfGraph(1, "Arad");
        listState.add(node1);
        cityGraph.addNodetoGraph(node1);
        NodesOfGraph node2 = new NodesOfGraph(2, "Bucharest");
        listState.add(node2);
        cityGraph.addNodetoGraph(node2);
        NodesOfGraph node3 = new NodesOfGraph(3, "Craiova");
        listState.add(node3);
        cityGraph.addNodetoGraph(node3);
        NodesOfGraph node4 = new NodesOfGraph(4, "Dobreta");
        listState.add(node4);
        cityGraph.addNodetoGraph(node4);
        NodesOfGraph node5 = new NodesOfGraph(5, "Eforie");
        listState.add(node5);
        cityGraph.addNodetoGraph(node5);
        NodesOfGraph node6 = new NodesOfGraph(6, "Fagaras");
        listState.add(node6);
        cityGraph.addNodetoGraph(node6);
        NodesOfGraph node7 = new NodesOfGraph(7, "Giurgiu");
        listState.add(node7);
        cityGraph.addNodetoGraph(node7);
        NodesOfGraph node8 = new NodesOfGraph(8, "Hirsova");
        listState.add(node8);
        cityGraph.addNodetoGraph(node8);
        NodesOfGraph node9 = new NodesOfGraph(9, "lasi");
        listState.add(node9);
        cityGraph.addNodetoGraph(node9);
        NodesOfGraph node10 = new NodesOfGraph(10, "Lugoj");
        listState.add(node10);
        cityGraph.addNodetoGraph(node10);
        NodesOfGraph node11 = new NodesOfGraph(11, "Mehadia");
        listState.add(node11);
        cityGraph.addNodetoGraph(node11);
        NodesOfGraph node12 = new NodesOfGraph(12, "Neamt");
        listState.add(node12);
        cityGraph.addNodetoGraph(node12);
        NodesOfGraph node13 = new NodesOfGraph(13, "Oradea");
        listState.add(node13);
        cityGraph.addNodetoGraph(node13);
        NodesOfGraph node14 = new NodesOfGraph(14, "Pitesti");
        listState.add(node14);
        cityGraph.addNodetoGraph(node14);
        NodesOfGraph node15 = new NodesOfGraph(15, "Rimnicu Vilcea");
        listState.add(node15);
        cityGraph.addNodetoGraph(node15);
        NodesOfGraph node16 = new NodesOfGraph(16, "Sibiu");
        listState.add(node16);
        cityGraph.addNodetoGraph(node16);
        NodesOfGraph node17 = new NodesOfGraph(17, "Timisoara");
        listState.add(node17);
        cityGraph.addNodetoGraph(node17);
        NodesOfGraph node18 = new NodesOfGraph(18, "Urziceni");
        listState.add(node18);
        cityGraph.addNodetoGraph(node18);
        NodesOfGraph node19 = new NodesOfGraph(19, "Vaslui");
        listState.add(node19);
        cityGraph.addNodetoGraph(node19);
        NodesOfGraph node20 = new NodesOfGraph(20, "Zerind");
        listState.add(node20);
        cityGraph.addNodetoGraph(node20);
    }

    public void creatCityGraph() {
        ArrayList<EdgesOfGraph> edgesOfGraphs = creatActios();
        creatState();
        setHeuristic();
        ArrayList<NodesOfGraph> addedNode = new ArrayList<>();
        ArrayList<EdgesOfGraph> actions = new ArrayList<>();
        NodesOfGraph currentState = setInitialState();
        addedNode.add(currentState);
        int count = 0;
        //   actions = Actions(currentState);
        while (!addedNode.isEmpty() && count < 47) {
            currentState = addedNode.remove(addedNode.size() - 1);
            actions = Actions(currentState, edgesOfGraphs);
            if (currentState.getNodeTitle().equals("Bucharest"))
                currentState.setGoal(true);
            for (EdgesOfGraph action : actions) {
                if (!currentState.edgesOfNode.contains(action)) {

                    cityGraph.addEdgetoGraph(currentState.getSeqNumOfNode(), action);
                    count++;
                    //  System.out.println("count:" + count);
                    addedNode.add(results(action));
                }

            }


        }
//        BFSsearch bfSsearch = new BFSsearch(cityGraph);
       // bfSsearch.BFSGraph();
//        bfSsearch.BFSTree();
//       bfSsearch.showPath();
//        UniformCostSearch uniformCostSearch=new UniformCostSearch(cityGraph);
    //    uniformCostSearch.UniformCostSearchGraph();
//        uniformCostSearch.UniformCostSearchTree();
//        uniformCostSearch.showPath();
//        ASSearch asSearch=new ASSearch(cityGraph,heuristic);
//       // asSearch.ASSearchGraph();
//       asSearch.ASSearchTree();
//        asSearch.showPath();
      //  GreedySearch greedySearch=new GreedySearch(cityGraph,heuristic);
//        greedySearch.GreedySearchGraph();
//        greedySearch.GreedySearchTree();
//        greedySearch.showPath();
//        DFSsearch  dfssearch=new DFSsearch(cityGraph);
      //  dfssearch.DFSsearchTree(20) ;
       // dfssearch.limitedDFS(3);
//     dfssearch.iterativeDFS();
//        dfssearch.DFSGraph() ;
//      dfssearch.showPath();
    }

    public void printGraph() {
        for (int i = 1; i < cityGraph.nodesOfgraph.size(); i++) {
            System.out.println("---------------------------------");
            System.out.println(cityGraph.nodesOfgraph.get(i).getNodeTitle() + "***");
            System.out.println();
            for (EdgesOfGraph e : cityGraph.nodesOfgraph.get(i).edgesOfNode)
                System.out.println(e.getTail() + "-->" + e.getHead() + "cost:" + e.getCostOfEdge());
            System.out.println("********************************");

        }
    }

    public ArrayList<EdgesOfGraph> Actions(NodesOfGraph state, ArrayList<EdgesOfGraph> e) {
        ArrayList<EdgesOfGraph> arrayList = new ArrayList<>();

        switch (state.getNodeTitle().toLowerCase()) {
            case "arad":

                arrayList.add(e.get(1));
                arrayList.add(e.get(2));
                arrayList.add(e.get(3));
                break;
            case "bucharest":

                arrayList.add(e.get(4));
                arrayList.add(e.get(5));
                arrayList.add(e.get(6));
                arrayList.add(e.get(7));
                break;
            case "craiova":

                arrayList.add(e.get(8));
                arrayList.add(e.get(9));
                arrayList.add(e.get(10));
                break;
            case "dobreta":

                arrayList.add(e.get(11));
                arrayList.add(e.get(12));
                break;
            case "eforie":

                arrayList.add(e.get(13));
                break;
            case "fagaras":

                arrayList.add(e.get(14));
                arrayList.add(e.get(15));
                break;
            case "giurgiu":

                arrayList.add(e.get(16));
                break;
            case "hirsova":

                arrayList.add(e.get(17));
                arrayList.add(e.get(18));
                break;
            case "lasi":

                arrayList.add(e.get(19));
                arrayList.add(e.get(20));
                break;
            case "lugoj":

                arrayList.add(e.get(21));
                arrayList.add(e.get(22));
                break;
            case "mehadia":

                arrayList.add(e.get(23));
                arrayList.add(e.get(24));
                break;
            case "neamt":

                arrayList.add(e.get(25));

                break;
            case "oradea":

                arrayList.add(e.get(26));
                arrayList.add(e.get(27));
                break;
            case "pitesti":

                arrayList.add(e.get(28));
                arrayList.add(e.get(29));
                arrayList.add(e.get(30));
                break;

            case "rimnicu vilcea":

                arrayList.add(e.get(31));
                arrayList.add(e.get(32));
                arrayList.add(e.get(33));
                break;
            case "sibiu":

                arrayList.add(e.get(34));
                arrayList.add(e.get(35));
                arrayList.add(e.get(36));
                arrayList.add(e.get(37));
                break;
            case "timisoara":

                arrayList.add(e.get(38));
                arrayList.add(e.get(39));

                break;
            case "urziceni":

                arrayList.add(e.get(40));
                arrayList.add(e.get(41));
                arrayList.add(e.get(42));

                break;
            case "vaslui":

                arrayList.add(e.get(43));
                arrayList.add(e.get(44));

                break;
            case "zerind":

                arrayList.add(e.get(45));
                arrayList.add(e.get(46));

                break;
        }
        return arrayList;
    }

    public NodesOfGraph results(EdgesOfGraph edgesOfGraph) {

        return cityGraph.nodesOfgraph.get(edgesOfGraph.getTail());
    }

    public void isGoal() {

    }

    public NodesOfGraph setInitialState() {
        // NodesOfGraph startState=new NodesOfGraph(1,"Arad");
        //    cityGraph.nodesOfgraph.add(listState.get(0));
        return listState.get(0);
    }

    public float computeCostOfAction(String head, String tail) {
        float returns = 0;
        tail.toLowerCase();
        switch (head.toLowerCase()) {
            case "arad":
                switch (tail) {
                    case "zernid":
                        returns = 75;
                        break;
                    case "sibiu":
                        returns = 140;
                        break;
                    case "timisoara":
                        returns = 118;
                        break;
                }
                break;
            case "bucharest":
                switch (tail) {
                    case "urziceni":
                        returns = 85;
                        break;
                    case "giurgiu":
                        returns = 90;
                        break;
                    case "pitesti":
                        returns = 101;
                        break;
                    case "fagaras":
                        returns = 211;
                        break;
                }
                break;
            case "craiova":
                switch (tail) {
                    case "dobreta":
                        returns = 120;
                        break;
                    case "pitesti":
                        returns = 138;
                        break;
                    case "rimnicu vilcea":
                        returns = 146;
                        break;
                }
                break;
            case "dobreta":
                switch (tail) {
                    case "craiova":
                        returns = 120;
                        break;
                    case "mehadia":
                        returns = 75;
                        break;
                }
                break;
            case "eforie":
                switch (tail) {
                    case "hirsova":
                        returns = 86;
                        break;
                }
                break;
            case "fagaras":
                switch (tail) {
                    case "sibiu":
                        returns = 99;
                        break;
                    case "bucharest":
                        returns = 211;
                        break;
                }
                break;
            case "giurgiu":
                returns = 90;
                break;
            case "hirsova":
                switch (tail) {
                    case "urziceni":
                        returns = 98;
                        break;
                    case "eforie":
                        returns = 86;
                        break;
                }
                break;
            case "lasi":
                switch (tail) {
                    case "vaslui":
                        returns = 92;
                        break;
                    case "neamt":
                        returns = 87;
                        break;
                }
                break;
            case "lugoj":
                switch (tail) {
                    case "timisoara":
                        returns = 111;
                        break;
                    case "mehadia":
                        returns = 75;
                        break;
                }
                break;
            case "mehadia":
                switch (tail) {
                    case "doberta":
                        returns = 75;
                        break;
                    case "lugoj":
                        returns = 70;
                        break;
                }
                break;
            case "neamt":
                returns = 87;
                break;
            case "oradea":
                switch (tail) {
                    case "zernid":
                        returns = 71;
                        break;
                    case "sibiu":
                        returns = 151;
                        break;
                }
                break;
            case "pitesti":
                switch (tail) {
                    case "craiova":
                        returns = 138;
                        break;
                    case "rimnicu vilcea":
                        returns = 97;
                        break;
                    case "bucharest":
                        returns = 101;
                        break;
                }
                break;
            case "rimnicu vilcea":
                switch (tail) {
                    case "sibiu":
                        returns = 80;
                        break;
                    case "pitesti":
                        returns = 97;
                        break;
                    case "craiova":
                        returns = 146;
                        break;
                }
                break;
            case "sibiu":
                switch (tail) {
                    case "arad":
                        returns = 75;
                        break;
                    case "rimnicu vilcea":
                        returns = 80;
                        break;
                    case "oradea":
                        returns = 151;
                        break;
                    case "fagaras":
                        returns = 99;
                        break;
                }
                break;
            case "timisoara":
                switch (tail) {
                    case "arad":
                        returns = 118;
                        break;
                    case "lugoj":
                        returns = 111;
                        break;
                }
                break;
            case "urziceni":
                switch (tail) {
                    case "hirsova":
                        returns = 98;
                        break;
                    case "bucharest":
                        returns = 85;
                        break;
                    case "vaslui":
                        returns = 142;
                        break;
                }
                break;
            case "vaslui":
                switch (tail) {
                    case "lasi":
                        returns = 92;
                        break;
                    case "urziceni":
                        returns = 142;
                        break;
                }
                break;
            case "zerind":
                switch (tail) {
                    case "oradea":
                        returns = 71;
                        break;
                    case "arad":
                        returns = 75;
                        break;
                }
                break;

        }
        return returns;
    }
}