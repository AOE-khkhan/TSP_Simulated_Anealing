package com.company;

import com.sun.org.apache.bcel.internal.generic.IF_ACMPEQ;

import java.util.ArrayList;
import java.util.Random;

public class Genetic {
    private Graph problemState;
    private ArrayList<GraphOfpopulation> populationlist;
    private int populationSize;
    private int numberOfGenerations;
    private int tornumentSize;
    private float mutationRate;
    private GraphOfpopulation finall;
    public ArrayList<GraphOfpopulation> selectParent;
    public ArrayList<GraphOfpopulation> childN;
    private float maxFit = 0;
    private float minFit =100;
    private float mediumFit = 0;

    public Genetic(Graph nodesOfGraph, int populationSize, int numberOfGenerations, int tornumentSize, float mutationRate) {
        this.problemState = nodesOfGraph;
        this.populationSize = populationSize;
        this.tornumentSize = tornumentSize;
        this.numberOfGenerations = numberOfGenerations;
        this.mutationRate = mutationRate;
        selectParent = new ArrayList<>();
        childN = new ArrayList<>();
    }

    public void runGenetic() {

        creatPopulation();
        calculatefitnessFunction1();
        float[] min=new float[numberOfGenerations] ;
        float[] max=new float[numberOfGenerations] ;
        float[] average=new float[numberOfGenerations] ;
        for (int i = 0; i < numberOfGenerations; i++) {
            childN.removeAll(childN);
            selectParent.removeAll(selectParent);
           // System.out.println("iterative:" + i);
            tornumentSelection();
            //System.out.println("parent select");
            crossOver();
            //   System.out.println("cross over ");
            mutation();
            fittnessFunction();
           min[i]=minFit;
           max[i]=maxFit ;
           average[i]=mediumFit ;

            createNewPupulation();

          // System.out.println(i+": ("+minFit+","+maxFit +")");

        }
        finall = childN.get(0);
        for (int i = 0; i < childN.size(); i++)
            if (finall.fitnessFunction < childN.get(i).fitnessFunction)
                finall = childN.get(i);

        System.out.println();
        System.out.println();
        for (int i=0 ;i<numberOfGenerations ;i++){
            System.out.println(average[i]);
        }
        System.out.println();
        System.out.println();
        for (int i=0 ;i<numberOfGenerations ;i++){
            System.out.println(min[i]);
        }
        System.out.println();
        System.out.println();
        for (int i=0 ;i<numberOfGenerations ;i++){
            System.out.println(max[i]);
        }
    }

    public void creatPopulation() {
        populationlist = new ArrayList<>();
        for (int i = 0; i < populationSize; i++) {
            String[] nodeC = new String[problemState.getNumOfNode() + 1];
            for (int j = 1; j < problemState.getNumOfNode() + 1; j++) {
                Random random = new Random();
                int randomColor = (Math.abs(random.nextInt()) % 3) + 1;
                switch (randomColor) {
                    case 1:
                        nodeC[j] = NodeColor.BLUE;
                        break;
                    case 2:
                        nodeC[j] = NodeColor.GREEN;
                        break;
                    case 3:
                        nodeC[j] = NodeColor.RED;
                        break;
                }
            }
            populationlist.add(new GraphOfpopulation(nodeC));
        }
    }

    public void calculatefitnessFunction1() {
        for (GraphOfpopulation g : populationlist) {
            int[] specChromosome;
            specChromosome = evaluationFunction(g.nodecColor);
            g.fitnessFunction = (float) specChromosome[1] / specChromosome[0];
        }
    }

    public void calculatefitnessFunction2(GraphOfpopulation g) {
        int[] specChromosome;
        specChromosome = evaluationFunction(g.nodecColor);
        g.fitnessFunction = (float) specChromosome[1] / specChromosome[0];
    }

    public int[] evaluationFunction(String[] nodeColors) {
        int conflict = 0;
        int[] result = new int[2];
        for (int i = 1; i < nodeColors.length; i++) {
            NodesOfGraph currentNode = problemState.nodesOfgraph.get(i);
            for (EdgesOfGraph e : currentNode.edgesOfNode) {
                result[0]++;
                if (!nodeColors[i].equals(nodeColors[e.getTail()]))
                    conflict++;
            }
        }
        result[0] = result[0] / 2;
        result[1] = conflict / 2;
        return result;
    }

    public void tornumentSelection() {
        ArrayList<GraphOfpopulation> arrayList = new ArrayList<>();
        GraphOfpopulation selectChromosome;
        int numoFselect = populationlist.size() / tornumentSize;
        for (int i = 0; i < numoFselect; i++) {
            for (int j = i * tornumentSize; j <( i * tornumentSize+tornumentSize); j++) {
                Random random = new Random();
                int k = (Math.abs(random.nextInt()) % tornumentSize);
                if (k+j>=populationSize)
                    arrayList.add(populationlist.get((k + j)%populationSize));
                else
                    arrayList.add(populationlist.get((k + j)));
            }
            selectChromosome = arrayList.get(0);
            for (GraphOfpopulation g : arrayList) {
                if (selectChromosome.fitnessFunction < g.fitnessFunction)
                    selectChromosome = g;
            }
            selectParent.add(selectChromosome);
        }
    }

    public void crossOver() {
        GraphOfpopulation child = new GraphOfpopulation(new String[problemState.getNumOfNode() + 1]);
        for (int i = 0; i < selectParent.size(); i++) {
            for (int j = i; j < selectParent.size(); j++) {
                for (int k = 1; k < problemState.getNumOfNode() + 1; k++) {
                    if (k %2== 1)
                        child.nodecColor[k] = selectParent.get(i).nodecColor[k];
                    else
                        child.nodecColor[k] = selectParent.get(j).nodecColor[k];
                }
                calculatefitnessFunction2(child);
                childN.add(child);
            }
        }
    }

    public void mutation() {
        float mutatedGenomes = populationSize * problemState.getNumOfNode() * mutationRate;
        int mutate = 0;
        while (mutate < mutatedGenomes) {
            Random random = new Random();
            int randomState = (Math.abs(random.nextInt()) % childN.size());
            int randomColor = (Math.abs(random.nextInt()) % 3) + 1;
            switch (randomColor) {
                case 1:
                    childN.get(randomState).nodecColor[randomColor] = NodeColor.BLUE;
                    calculatefitnessFunction2(childN.get(randomState));
                    break;
                case 2:
                    childN.get(randomState).nodecColor[randomColor] = NodeColor.GREEN;
                    calculatefitnessFunction2(childN.get(randomState));
                    break;
                case 3:
                    childN.get(randomState).nodecColor[randomColor] = NodeColor.RED;
                    calculatefitnessFunction2(childN.get(randomState));
                    break;
            }
            mutate++;
        }
    }

    public void createNewPupulation() {
        Random random = new Random();
        populationlist.removeAll(populationlist);

        for (int i = 0; i < populationSize; i++) {
            populationlist.add(childN.get(Math.abs(new Random().nextInt()) % childN.size()));
        }
    }

    public void showColor() {
        System.out.println(finall.fitnessFunction + "fffffffiiiiiiiiittttttttt");
        for (String s : finall.nodecColor)
            System.out.println(s);
    }

    public int evaluationFunction(GraphOfpopulation graphOfpopulation) {
        int conflict = 0;
        for (int i = 1; i < problemState.getNumOfNode() + 1; i++) {
            NodesOfGraph currentNode = problemState.nodesOfgraph.get(i);
            for (EdgesOfGraph e : currentNode.edgesOfNode) {
                if (graphOfpopulation.nodecColor[i].equals(graphOfpopulation.nodecColor[e.getTail()]))
                    conflict++;
            }
        }
        return conflict / 2;
    }

    public void fittnessFunction() {
        mediumFit=0;
        minFit=100;
        maxFit=0;
        for (int i = 0; i < populationlist.size(); i++) {
            if (minFit >evaluation( populationlist.get(i).nodecColor))
                minFit = evaluation( populationlist.get(i).nodecColor);
            if (maxFit <evaluation( populationlist.get(i).nodecColor))
                maxFit = evaluation( populationlist.get(i).nodecColor);

            mediumFit += evaluation( populationlist.get(i).nodecColor);


        }
     //   System.out.println(mediumFit+"********"+populationlist.size());
        mediumFit =(float) (mediumFit /populationSize);
    }
    public int evaluation(String[] nodeColors) {
        int conflict = 0;
        for (int i = 1; i < nodeColors.length; i++) {
            NodesOfGraph currentNode = problemState.nodesOfgraph.get(i);
            for (EdgesOfGraph e : currentNode.edgesOfNode) {
                if (nodeColors[i].equals(nodeColors[e.getTail()]))
                    conflict++;
            }
        }
        return conflict / 2;
    }


}
