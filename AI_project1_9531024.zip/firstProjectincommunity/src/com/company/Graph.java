package com.company;

import java.util.ArrayList;
import java.util.LinkedList;

public class Graph {
   public NodesOfGraph[][] graph ;
   public ArrayList<NodesOfGraph> nodesOfgraph ;
   public  ArrayList<NodesOfGraph> goalStates;

   private  int numOfNode ;
    public Graph(int numOfedge){
        this.numOfNode=numOfedge;
       nodesOfgraph=new ArrayList<>();
     //  nodesOfgraph.add(new NodesOfGraph(0,""));
       goalStates=new ArrayList<>();
       nodesOfgraph.add(null);

    }

    public int getNumOfNode() {
        return numOfNode;
    }

    public  void  addEdgetoGraph(int num, EdgesOfGraph newEdge){

       nodesOfgraph.get(num).edgesOfNode.add(newEdge);

    }
    public  void  addNodetoGraph(NodesOfGraph newNode){
        nodesOfgraph.add(newNode);
        newNode.edgesOfNode=new LinkedList<>();
    }
}
