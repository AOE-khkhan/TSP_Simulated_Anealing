package com.company;

import com.company.Graph;
import com.company.NodesOfGraph;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Queue;

public class BFSsearch {
    private Graph problemStates ;
    private QueueM<NodesOfGraph> openlist;
    private ArrayList<NodesOfGraph>  closeList ;
    private  ArrayList<NodesOfGraph> foundedPath ;
    private  int numOfnodeVisit=1;
    private  int numOfnodexpand=0;
    private NodesOfGraph[] parents ;
    private int  costPath ;
    public BFSsearch(Graph problemStates){

        this.problemStates=problemStates;
         foundedPath=new ArrayList();
        openlist=new QueueM<>(problemStates.getNumOfNode());
        closeList=new ArrayList();
        parents=new NodesOfGraph[problemStates.getNumOfNode()+1];
    }
    public boolean BFSGraph(){
       // openlist=new QueueM<ListforexpandNode>(problemStates.nodesOfgraph);
        NodesOfGraph startState=problemStates.nodesOfgraph.get(1);
        NodesOfGraph currentState=null;
        parents[startState.getSeqNumOfNode()]=null ;
        if (startState.isGoal()) foundedPath.add(startState);
        openlist.addToQueue(startState);
        startState.setInOpenList(true);
        while (!openlist.empty()){

           currentState=openlist.getFromQueue();
            currentState.setInOpenList(false);
           closeList.add(currentState);
           currentState.setInCloseList(true);
           numOfnodexpand++;
            for (EdgesOfGraph e:
                 currentState.edgesOfNode) {
               if (!problemStates.nodesOfgraph.get(e.getTail()).isInOpenList()&&!problemStates.nodesOfgraph.get(e.getTail()).isInCloseList()){
                   if (problemStates.nodesOfgraph.get(e.getTail()).isGoal()) {
                       solution(parents, currentState, problemStates.nodesOfgraph.get(e.getTail()));
                       return true ;
                   }
                   parents[e.getTail()]=currentState ;
                   openlist.addToQueue(problemStates.nodesOfgraph.get(e.getTail()));
                   problemStates.nodesOfgraph.get(e.getTail()).setInOpenList(true);
                   numOfnodeVisit++;
               }
            }

        }
        return  false;

    }
    public boolean BFSTree(){
        NodesOfGraph startState=problemStates.nodesOfgraph.get(1);
        NodesOfGraph currentState=null;
        parents[startState.getSeqNumOfNode()]=null ;
        if (startState.isGoal()) foundedPath.add(startState);
        openlist.addToQueue(startState);
        startState.setInOpenList(true);
        while (!openlist.empty()){

            currentState=openlist.getFromQueue();
            currentState.setInOpenList(false);
          //  closeList.add(currentState);
            currentState.setInCloseList(true);
            numOfnodexpand++;
            for (EdgesOfGraph e:
                    currentState.edgesOfNode) {
                if (!problemStates.nodesOfgraph.get(e.getTail()).isInOpenList()) {
                    if (problemStates.nodesOfgraph.get(e.getTail()).isGoal()){
                solution(parents, currentState, problemStates.nodesOfgraph.get(e.getTail()));
                return true ;
            }
                   if (!problemStates.nodesOfgraph.get(e.getTail()).isInCloseList()) {
                       parents[e.getTail()] = currentState;
                       problemStates.nodesOfgraph.get(e.getTail()).setInCloseList(true);
                   }
                    openlist.addToQueue(problemStates.nodesOfgraph.get(e.getTail()));
                    problemStates.nodesOfgraph.get(e.getTail()).setInOpenList(true);
                    numOfnodeVisit++;
                }
            }

        }
        return  false;

    }
    public ArrayList<NodesOfGraph> solution(NodesOfGraph[] closeList, NodesOfGraph parentGoal, NodesOfGraph goal) {
        closeList[1]=null ;
        foundedPath.add(goal);
        foundedPath.add(parentGoal);
        costPath++ ;
        NodesOfGraph parentNode = parentGoal;
        while (closeList[parentNode.getSeqNumOfNode()]!=null) {
            if (closeList[parentNode.getSeqNumOfNode()] != null) {
                foundedPath.add(closeList[parentNode.getSeqNumOfNode()]);
                costPath++;
                parentNode = closeList[parentNode.getSeqNumOfNode()];

            }


        }
        return foundedPath;
    }
    public  void  showPath(){
        System.out.println("---------------PATH---------------");
        for (NodesOfGraph node :
             foundedPath) {
            System.out.printf(node.getNodeTitle() +"<--");
        }
        System.out.println();
        System.out.println("CostOfPath:"+costPath);
        System.out.println("NumOfExpandExpand:"+numOfnodexpand);
        System.out.println("NumOfvisitvisit:"+numOfnodeVisit);

    }
}
