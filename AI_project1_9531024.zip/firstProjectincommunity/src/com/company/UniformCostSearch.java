package com.company;

import java.util.ArrayList;

public class UniformCostSearch {
    private Graph problemStates;
    private float totalCost = 0;
    private ArrayList<PathCostList> openlist;
    private ArrayList<PathCostList> closeList;
    private ArrayList<NodesOfGraph> foundedPath;
    private NodesOfGraph[] parents;
    private int numOfnodeVisit = 1;
    private int numOfnodexpand = 0;

    public UniformCostSearch(Graph problemStates) {

        this.problemStates = problemStates;
        foundedPath = new ArrayList();
        openlist = new ArrayList<>();
        closeList = new ArrayList();
        parents = new NodesOfGraph[problemStates.getNumOfNode() + 1];
        //  parents.add(null);
    }

    public boolean UniformCostSearchGraph() {
        NodesOfGraph startState = problemStates.nodesOfgraph.get(1);
        PathCostList currentState = null;
        if (startState.isGoal()) foundedPath.add(startState);
        openlist.add(new PathCostList(startState, 0));
        parents[startState.getSeqNumOfNode()] = null;
        startState.setInOpenList(true);
        while (!PathCostList.isEmpty(openlist)) {
            currentState = PathCostList.getShortestPathUni(openlist);
            closeList.add(currentState);
            currentState.nodesOfGraph.setInOpenList(false);
            currentState.nodesOfGraph.setInCloseList(true);
            numOfnodexpand++;
            if (currentState.nodesOfGraph.isGoal()) {
                solution(parents, currentState.nodesOfGraph, currentState.nodesOfGraph);
                totalCost = PathCostList.findNode(closeList, currentState.nodesOfGraph).totalCost;
              //  System.out.println(totalCost + "tatal cost");
                return true;
            }

            for (EdgesOfGraph e :
                    currentState.nodesOfGraph.edgesOfNode) {
                if (!problemStates.nodesOfgraph.get(e.getTail()).isInOpenList() && !problemStates.nodesOfgraph.get(e.getTail()).isInCloseList()) {

                    openlist.add(new PathCostList(problemStates.nodesOfgraph.get(e.getTail()), currentState.totalCost + e.getCostOfEdge()));
                    parents[e.getTail()] = currentState.nodesOfGraph;
                    problemStates.nodesOfgraph.get(e.getTail()).setInOpenList(true);
                    numOfnodeVisit++;
                } else if (problemStates.nodesOfgraph.get(e.getTail()).isInCloseList()) {
                    if ((currentState.totalCost + e.getCostOfEdge()) < PathCostList.findNode(closeList, problemStates.nodesOfgraph.get(e.getTail())).totalCost) {
                        closeList.remove(PathCostList.findNode(closeList, problemStates.nodesOfgraph.get(e.getTail())));
                        openlist.add(new PathCostList(problemStates.nodesOfgraph.get(e.getTail()), currentState.totalCost + e.getCostOfEdge()));

                        parents[e.getTail()] = currentState.nodesOfGraph;
                    }

                } else if (problemStates.nodesOfgraph.get(e.getTail()).isInOpenList()) {
                    if ((currentState.totalCost + e.getCostOfEdge()) < PathCostList.findNode(openlist, problemStates.nodesOfgraph.get(e.getTail())).totalCost) {
                        parents[e.getTail()] = currentState.nodesOfGraph;
                        PathCostList.findNode(openlist, problemStates.nodesOfgraph.get(e.getTail())).totalCost = currentState.totalCost + e.getCostOfEdge();
                    }
                }
            }

        }
        return false;

    }
    public boolean UniformCostSearchTree() {
        NodesOfGraph startState = problemStates.nodesOfgraph.get(1);
        PathCostList currentState = null;
        if (startState.isGoal()) foundedPath.add(startState);
        openlist.add(new PathCostList(startState, 0));
        parents[startState.getSeqNumOfNode()] = null;
        startState.setInOpenList(true);
        while (!PathCostList.isEmpty(openlist)) {
            currentState = PathCostList.getShortestPathUni(openlist);
            currentState.nodesOfGraph.setInOpenList(false);
            numOfnodexpand++;
            if (currentState.nodesOfGraph.isGoal()) {
                solution(parents, currentState.nodesOfGraph, currentState.nodesOfGraph);
                totalCost = PathCostList.findNode(closeList, currentState.nodesOfGraph).totalCost;
                return true;
            }

            for (EdgesOfGraph e :
                    currentState.nodesOfGraph.edgesOfNode) {
                if (!problemStates.nodesOfgraph.get(e.getTail()).isInOpenList() ) {

                    openlist.add(new PathCostList(problemStates.nodesOfgraph.get(e.getTail()), currentState.totalCost + e.getCostOfEdge()));
                    parents[e.getTail()] = currentState.nodesOfGraph;
                    problemStates.nodesOfgraph.get(e.getTail()).setInOpenList(true);
                    numOfnodeVisit++;
                } else if (problemStates.nodesOfgraph.get(e.getTail()).isInCloseList()) {
                    if ((currentState.totalCost + e.getCostOfEdge()) < PathCostList.findNode(closeList, problemStates.nodesOfgraph.get(e.getTail())).totalCost) {
                        closeList.remove(PathCostList.findNode(closeList, problemStates.nodesOfgraph.get(e.getTail())));
                        openlist.add(new PathCostList(problemStates.nodesOfgraph.get(e.getTail()), currentState.totalCost + e.getCostOfEdge()));

                        parents[e.getTail()] = currentState.nodesOfGraph;
                    }

                } else if (problemStates.nodesOfgraph.get(e.getTail()).isInOpenList()) {
                    if ((currentState.totalCost + e.getCostOfEdge()) < PathCostList.findNode(openlist, problemStates.nodesOfgraph.get(e.getTail())).totalCost) {
                        parents[e.getTail()] = currentState.nodesOfGraph;
                        PathCostList.findNode(openlist, problemStates.nodesOfgraph.get(e.getTail())).totalCost = currentState.totalCost + e.getCostOfEdge();
                    }
                }
            }

        }
        return false;

    }

    public ArrayList<NodesOfGraph> solution(NodesOfGraph[] closeList, NodesOfGraph parentGoal, NodesOfGraph goal) {
        foundedPath.add(goal);
        foundedPath.add(closeList[goal.getSeqNumOfNode()]);
        NodesOfGraph parentNode = closeList[goal.getSeqNumOfNode()];
        while (closeList[parentNode.getSeqNumOfNode()] != null) {
            if (closeList[parentNode.getSeqNumOfNode()] != null) {
                foundedPath.add(closeList[parentNode.getSeqNumOfNode()]);
                parentNode = closeList[parentNode.getSeqNumOfNode()];

            }


        }
        return foundedPath;
    }


    public void showPath() {
        for (NodesOfGraph node :
                foundedPath) {
            System.out.printf(node.getNodeTitle() + "<--");
        }
        System.out.println();
        System.out.println("CostOfPath:"+totalCost);
        System.out.println("NumOfExpandExpand:"+numOfnodexpand);
        System.out.println("NumOfvisitvisit:"+numOfnodeVisit);

    }
}
