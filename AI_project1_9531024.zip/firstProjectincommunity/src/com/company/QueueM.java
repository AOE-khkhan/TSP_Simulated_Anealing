package com.company;

import java.util.ArrayList;
import java.util.Queue;

public class QueueM<E> {
    private  int front ;
    private  int rear ;
    private  int maxSize;
    ArrayList<E> queue;
    public QueueM(int maxSize){
        this.maxSize=maxSize;
        front=0;//
        rear=0;
        queue=new ArrayList<>();
    }
    public void  addToQueue(E e){
        if (rear==maxSize)
            return;
        else{
            queue.add(rear,e);
            rear++;
        }

    }
    public E  getFromQueue(){

        if (rear==front)
            return null ;
        else{
            int t=front;
            front++;
         return    queue.get(t);

        }


    }

    public boolean empty() {
        if(rear==front)
            return true;
        else
            return false ;
    }
}
