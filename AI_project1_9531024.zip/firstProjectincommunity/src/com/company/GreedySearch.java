package com.company;

import java.util.ArrayList;

public class GreedySearch {
    private Graph problemStates;
    private float totalCost = 0;
    private  float[] heuristic;
    private ArrayList<PathCostList> openlist;
    private ArrayList<PathCostList> closeList;
    private ArrayList<NodesOfGraph> foundedPath;
    private NodesOfGraph[] parents;
    private int numOfnodeVisit = 1;
    private int numOfnodexpand = 0;

    public GreedySearch(Graph problemStates,float[] heuristic) {

        this.problemStates = problemStates;
        foundedPath = new ArrayList();
        openlist = new ArrayList<>();
        closeList = new ArrayList();
        parents = new NodesOfGraph[problemStates.getNumOfNode()+1];
        this.heuristic=heuristic ;

    }

    public boolean GreedySearchGraph() {
        NodesOfGraph startState = problemStates.nodesOfgraph.get(1);
        PathCostList currentState = null;
        if (startState.isGoal()) foundedPath.add(startState);
        openlist.add(new PathCostList(startState, heuristic[startState.getSeqNumOfNode()]));
        parents[startState.getSeqNumOfNode()]= null;
        startState.setInOpenList(true);
        while (!PathCostList.isEmpty(openlist)) {
            currentState = PathCostList.getShortestPathGreedy(openlist,heuristic);
            closeList.add(currentState);
            currentState.nodesOfGraph.setInCloseList(true);
            numOfnodexpand++;
            if (currentState.nodesOfGraph.isGoal()) {
                solution(parents, currentState.nodesOfGraph, currentState.nodesOfGraph);
                totalCost = PathCostList.findNode(closeList, currentState.nodesOfGraph).totalCost;
                System.out.println(totalCost + "tatal cost");
                return false;
            }
            for (EdgesOfGraph e :
                    currentState.nodesOfGraph.edgesOfNode) {
                if (!problemStates.nodesOfgraph.get(e.getTail()).isInOpenList() && !problemStates.nodesOfgraph.get(e.getTail()).isInCloseList()) {

                //    openlist.add(new PathCostList(problemStates.nodesOfgraph.get(e.getTail()),heuristic[e.getTail()] ));
                    openlist.add(new PathCostList(problemStates.nodesOfgraph.get(e.getTail()), currentState.totalCost + e.getCostOfEdge()));
                    parents[e.getTail()] =currentState.nodesOfGraph;
                    problemStates.nodesOfgraph.get(e.getTail()).setInOpenList(true);
                    numOfnodeVisit++;
                }
            }

        }
        return false;

    }
    public boolean GreedySearchTree() {
        NodesOfGraph startState = problemStates.nodesOfgraph.get(1);
        PathCostList currentState = null;
        if (startState.isGoal()) foundedPath.add(startState);
        openlist.add(new PathCostList(startState, heuristic[startState.getSeqNumOfNode()]));
        parents[startState.getSeqNumOfNode()]= null;
        startState.setInOpenList(true);
        while (!PathCostList.isEmpty(openlist)) {
            currentState = PathCostList.getShortestPathGreedy(openlist,heuristic);
            currentState.nodesOfGraph.setInOpenList(false);
           // closeList.add(currentState);
            //currentState.nodesOfGraph.setInCloseList(true);
            numOfnodexpand++;
            if (currentState.nodesOfGraph.isGoal()) {
                solution(parents, currentState.nodesOfGraph, currentState.nodesOfGraph);
                totalCost = PathCostList.findNode(closeList, currentState.nodesOfGraph).totalCost;
                System.out.println(totalCost + "tatal cost");
                return false;
            }
            for (EdgesOfGraph e :
                    currentState.nodesOfGraph.edgesOfNode) {
                if (!problemStates.nodesOfgraph.get(e.getTail()).isInOpenList()) {

                    //    openlist.add(new PathCostList(problemStates.nodesOfgraph.get(e.getTail()),heuristic[e.getTail()] ));
                    openlist.add(new PathCostList(problemStates.nodesOfgraph.get(e.getTail()), currentState.totalCost + e.getCostOfEdge()));
                    parents[e.getTail()] =currentState.nodesOfGraph;
                    problemStates.nodesOfgraph.get(e.getTail()).setInOpenList(true);
                    numOfnodeVisit++;
                }
            }

        }
        return false;

    }

    public ArrayList<NodesOfGraph> solution(NodesOfGraph[] closeList, NodesOfGraph parentGoal, NodesOfGraph goal) {
        foundedPath.add(goal);
        foundedPath.add(closeList[goal.getSeqNumOfNode()]);
        NodesOfGraph parentNode = closeList[goal.getSeqNumOfNode()];
        while (closeList[parentNode.getSeqNumOfNode()] != null) {
            if (closeList[parentNode.getSeqNumOfNode()] != null) {
                foundedPath.add(closeList[parentNode.getSeqNumOfNode()]);
                parentNode = closeList[parentNode.getSeqNumOfNode()];

            }


        }
        return foundedPath;
    }

    public void showPath() {
        for (NodesOfGraph node :
                foundedPath) {
            System.out.printf(node.getNodeTitle() + "<--");
        }
        System.out.println();
        System.out.println("CostOfPath:"+totalCost);
        System.out.println("NumOfExpandExpand:"+numOfnodexpand);
        System.out.println("NumOfvisitvisit:"+numOfnodeVisit);

    }
}
