package com.company;

public class GraphOfpopulation {
    public   String[] nodecColor ;
    public float fitnessFunction ;
    public GraphOfpopulation(String[] node){
      nodecColor=node;
    }
}
