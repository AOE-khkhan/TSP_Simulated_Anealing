package com.company;

import java.util.ArrayList;

public class DFSsearch {
    private Graph problemStates;
    private StackM<NodesOfGraph> openlist;
    private ArrayList<NodesOfGraph> closeList;
    private ArrayList<NodesOfGraph> foundedPath;
    private int numOfnodeVisit = 1;
    private int numOfnodexpand = 0;
    private int depth = 4;
    private NodesOfGraph[] parents;
private int   costOfPath=0 ;
    public DFSsearch(Graph problemStates) {
        parents = new NodesOfGraph[problemStates.getNumOfNode() + 1];
        this.problemStates = problemStates;
        foundedPath = new ArrayList();
        openlist = new StackM<>(problemStates.getNumOfNode());
        closeList = new ArrayList();
    }
    public boolean DFSGraph() {

            NodesOfGraph startState = problemStates.nodesOfgraph.get(1);
            NodesOfGraph currentState = null;
            if (startState.isGoal()) foundedPath.add(startState);
            openlist.addToStack(startState);
            parents[startState.getSeqNumOfNode()] = null;
            startState.setInOpenList(true);
           boolean result= recMethod(startState,15);
            return result ;
        }
    public boolean limitedDFS(int limit) {
        NodesOfGraph startState = problemStates.nodesOfgraph.get(1);
        NodesOfGraph currentState = null;
        if (startState.isGoal()) foundedPath.add(startState);
        openlist.addToStack(startState);
        parents[startState.getSeqNumOfNode()] = null;
        startState.setInOpenList(true);
       boolean result= recMethod(startState,limit);
      return result ;
    }
    public boolean DFSsearchTree(int limit) {
        NodesOfGraph startState = problemStates.nodesOfgraph.get(1);
        NodesOfGraph currentState = null;
        if (startState.isGoal()) foundedPath.add(startState);
        openlist.addToStack(startState);
        parents[startState.getSeqNumOfNode()] = null;
        startState.setInOpenList(true);
        recMethodTree(startState,limit);
        return false ;
    }

    public  boolean recMethod(NodesOfGraph node, int limit){
        boolean result =false ;
        if (limit==0){
            return false ;
        }else{
            numOfnodexpand++;
            closeList.add(node);
            node.setInCloseList(true);

            for (EdgesOfGraph e:node.edgesOfNode){
                openlist.addToStack(problemStates.nodesOfgraph.get(e.getTail()));
                numOfnodeVisit++;
                if (!e.visit&&!problemStates.nodesOfgraph.get(e.getTail()).isInCloseList()) {
                    e.visit=true ;
                    if (problemStates.nodesOfgraph.get(e.getTail()).isGoal()) {
                        solution(parents,node, problemStates.nodesOfgraph.get(e.getTail()));
                        return true;
                    }
                    parents[e.getTail()] = node;
                    numOfnodeVisit++;
                    problemStates.nodesOfgraph.get(e.getTail()).setInOpenList(true);
                    result=recMethod(problemStates.nodesOfgraph.get(e.getTail()),limit-1);
                    if (result)
                        return  true ;
                }

            }
        }
        return result ;
    }
    public  boolean recMethodTree(NodesOfGraph node, int limit){
        boolean result =false ;
        if (limit==0){
           // return false ;
        }else{
            numOfnodexpand++;
            node.setInOpenList(false);

            for (EdgesOfGraph e:node.edgesOfNode){
                openlist.addToStack(problemStates.nodesOfgraph.get(e.getTail()));
                numOfnodeVisit++;
                if (!!problemStates.nodesOfgraph.get(e.getTail()).isInOpenList()) {
                    if (problemStates.nodesOfgraph.get(e.getTail()).isGoal()) {
                        solution(parents,node, problemStates.nodesOfgraph.get(e.getTail()));
                        return true;
                    }
                    parents[e.getTail()] = node;
                    numOfnodeVisit++;
                    problemStates.nodesOfgraph.get(e.getTail()).setInOpenList(true);
                    result=recMethodTree(problemStates.nodesOfgraph.get(e.getTail()),limit-1);
                    if (result)
                        return  true ;
                }

            }
        }
        return result ;
    }

       public boolean iterativeDFS(){
        for (int d=0 ; ;d++){

            if (limitedDFS(d)) {
                System.out.println("limited that reach goal:"+d);
                return true;
            }
            reset();
        }

    }
    public  void  reset(){
        for (int i=1 ;i<problemStates.nodesOfgraph.size();i++){
            problemStates.nodesOfgraph.get(i).setInOpenList(false);
            problemStates.nodesOfgraph.get(i).setInCloseList(false);
            for (EdgesOfGraph e: problemStates.nodesOfgraph.get(i).edgesOfNode){
                e.visit=false ;
            }
        }
    }
/*
/* this method get goal node and its parent then
 */
    public ArrayList<NodesOfGraph> solution(NodesOfGraph[] closeList, NodesOfGraph parentGoal, NodesOfGraph goal) {
        foundedPath.add(goal);
        foundedPath.add(parentGoal);
        costOfPath++;
        NodesOfGraph parentNode = parentGoal;
        while (closeList[parentNode.getSeqNumOfNode()] != null) {
            if (closeList[parentNode.getSeqNumOfNode()] != null) {
                foundedPath.add(closeList[parentNode.getSeqNumOfNode()]);
                parentNode = closeList[parentNode.getSeqNumOfNode()];
                costOfPath++;

            }


        }
        return foundedPath;
    }

    public void showPath() {
        System.out.println("---------------PATH---------------");
        for (NodesOfGraph node :
                foundedPath) {
            System.out.printf(node.getNodeTitle() + "<--");
        }
        System.out.println();
        System.out.println("Cost:" + costOfPath);
        System.out.println("Expand:" + numOfnodexpand);
        System.out.println("visit:" + numOfnodeVisit);
    }
}
