package com.company;

import java.util.ArrayList;

public class PathCostList {
    public   float totalCost ;
    public NodesOfGraph nodesOfGraph ;
    public PathCostList(NodesOfGraph node,float cost){
        this.totalCost=cost;
        this.nodesOfGraph=node;
    }
    public static PathCostList getShortestPathUni(ArrayList<PathCostList> pathCostLists){

      PathCostList resultNode=pathCostLists.get(0);
        for (PathCostList node:
            pathCostLists ) {
            if (node.totalCost<resultNode.totalCost){
                resultNode=node ;
            }

        }
        pathCostLists.remove(resultNode);
        return  resultNode ;
    }
    public static PathCostList getShortestPathAs(ArrayList<PathCostList> pathCostLists,  float[] heuristic){

        PathCostList resultNode=pathCostLists.get(0);
        for (PathCostList node:
                pathCostLists ) {
            if (node.totalCost+heuristic[node.nodesOfGraph.getSeqNumOfNode()]<resultNode.totalCost+heuristic[resultNode.nodesOfGraph.getSeqNumOfNode()]){
                resultNode=node ;
            }

        }
        pathCostLists.remove(resultNode);
        return  resultNode ;
    }
    public static PathCostList getShortestPathGreedy(ArrayList<PathCostList> pathCostLists,  float[] heuristic){

        PathCostList resultNode=pathCostLists.get(0);
        for (PathCostList node:
                pathCostLists ) {
            if (heuristic[node.nodesOfGraph.getSeqNumOfNode()]<heuristic[resultNode.nodesOfGraph.getSeqNumOfNode()]){
                resultNode=node ;
            }

        }
        pathCostLists.remove(resultNode);
        return  resultNode ;
    }

    public static boolean isEmpty(ArrayList<PathCostList> pathCostLists){
        if(pathCostLists.isEmpty())
            return true;
        else
            return false ;
    }
    public static PathCostList findNode(ArrayList<PathCostList> pathCostLists,NodesOfGraph node ){
        for (PathCostList nodes:
                pathCostLists ) {
            if (nodes.nodesOfGraph.getSeqNumOfNode()==node.getSeqNumOfNode()){
              return nodes ;
            }

        }
        return null ;
    }
}
